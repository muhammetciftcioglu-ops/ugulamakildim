package com.example.applock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.*

class LockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val target = intent.getStringExtra("pkg") ?: ""
        val self = intent.getBooleanExtra("self", false)
        val hasPin = Prefs.has(this, "pin")
        val hasPattern = Prefs.has(this, "pattern")
        if (!hasPin && !hasPattern) { finish(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply { text = Prefs.message(this@LockActivity); textSize = 22f; gravity = Gravity.CENTER })

        if (hasPattern) {
            val pv = PatternView(this) { s ->
                if (Prefs.check(this, "pattern", s)) done(target, self)
                else Toast.makeText(this, "Yanlış desen", Toast.LENGTH_SHORT).show()
            }
            root.addView(pv)
        }
        if (hasPin) {
            val et = EditText(this).apply {
                hint = "PIN"
                gravity = Gravity.CENTER
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            }
            val ok = Button(this).apply {
                text = "Aç"
                setOnClickListener {
                    if (Prefs.check(this@LockActivity, "pin", et.text.toString())) done(target, self)
                    else { et.text.clear(); Toast.makeText(this@LockActivity, "Yanlış PIN", Toast.LENGTH_SHORT).show() }
                }
            }
            root.addView(et); root.addView(ok)
        }
        setContentView(root)
    }

    private fun done(pkg: String, self: Boolean) {
        if (self) {
            Session.mainOk = true
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else Session.unlocked = pkg
        finish()
    }

    @Deprecated("Deprecated")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
