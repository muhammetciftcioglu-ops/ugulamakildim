package com.example.applock

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

object Session {
    var unlocked: String? = null
    var last: String? = null
    var mainOk = false
    var leftAt = 0L
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(c: Context, v: String): String {
        val salt = sp(c).getString("salt", null)
            ?: UUID.randomUUID().toString().also { sp(c).edit().putString("salt", it).apply() }
        return MessageDigest.getInstance("SHA-256").digest((salt + v).toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    fun set(c: Context, key: String, value: String) =
        sp(c).edit().putString(key, hash(c, value)).apply()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)

    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun graceMs(c: Context) = sp(c).getLong("grace", 30_000L)

    fun setGraceMs(c: Context, v: Long) = sp(c).edit().putLong("grace", v).apply()

    fun message(c: Context): String =
        (sp(c).getString("msg", "") ?: "").ifBlank { "Kilitli uygulama" }

    fun setMessage(c: Context, v: String) = sp(c).edit().putString("msg", v).apply()

    fun has(c: Context, key: String) = sp(c).contains(key)

    fun check(c: Context, key: String, value: String) =
        sp(c).getString(key, null) == hash(c, value)

    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet()) ?: emptySet()

    fun setLocked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("locked", s).apply()
}
