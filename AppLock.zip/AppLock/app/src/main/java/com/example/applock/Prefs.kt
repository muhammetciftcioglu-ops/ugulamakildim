package com.example.applock

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

object Session {
    var unlocked: String? = null
    var last: String? = null
    var mainOk = false
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(c: Context, v: String): String {
        val salt = sp(c).getString("salt", null)
            ?: UUID.randomUUID().toString().also { sp(c).edit().putString("salt", it).apply() }
        return MessageDigest.getInstance("SHA-256").digest((salt + v).toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    fun set(c: Context, key: String, value: String) =
        sp(c).edit().putString(key, hash(c, value)).apply()

    fun has(c: Context, key: String) = sp(c).contains(key)

    fun check(c: Context, key: String, value: String) =
        sp(c).getString(key, null) == hash(c, value)

    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet()) ?: emptySet()

    fun setLocked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("locked", s).apply()
}
