package com.example.applock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import kotlin.math.hypot

class PatternView(c: Context, private val onDone: (String) -> Unit) : View(c) {
    private val sel = mutableListOf<Int>()
    private var fx = 0f
    private var fy = 0f
    private var drawing = false
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF888888.toInt() }
    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1E88E5.toInt() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1E88E5.toInt(); strokeWidth = 12f; strokeCap = Paint.Cap.ROUND
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = (300 * resources.displayMetrics.density).toInt()
        setMeasuredDimension(s, s)
    }

    private fun cx(i: Int) = (i % 3 + 0.5f) * width / 3f
    private fun cy(i: Int) = (i / 3 + 0.5f) * height / 3f

    private fun hit(x: Float, y: Float) {
        for (i in 0..8) if (i !in sel && hypot(x - cx(i), y - cy(i)) < width / 8f) sel.add(i)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        fx = e.x; fy = e.y
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sel.clear(); drawing = true; hit(fx, fy) }
            MotionEvent.ACTION_MOVE -> hit(fx, fy)
            MotionEvent.ACTION_UP -> {
                drawing = false
                val s = sel.joinToString("")
                sel.clear()
                if (s.length >= 4) onDone(s)
                else Toast.makeText(context, "En az 4 nokta bağla", Toast.LENGTH_SHORT).show()
            }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        for (k in 1 until sel.size)
            c.drawLine(cx(sel[k - 1]), cy(sel[k - 1]), cx(sel[k]), cy(sel[k]), line)
        if (drawing && sel.isNotEmpty())
            c.drawLine(cx(sel.last()), cy(sel.last()), fx, fy, line)
        for (i in 0..8) c.drawCircle(cx(i), cy(i), 22f, if (i in sel) on else dot)
    }
}
