package com.example.applock

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    private var launcherPkg: String? = null

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            Session.unlocked = null
            Session.last = null
            Session.mainOk = false
        }
    }

    override fun onServiceConnected() {
        launcherPkg = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        val f = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOff, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenOff, f)
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenOff) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg.contains("inputmethod")) return
        Session.mainOk = false
        if (pkg == Session.last) return

        val now = SystemClock.elapsedRealtime()
        if (Session.last != null && Session.last == Session.unlocked) Session.leftAt = now
        Session.last = pkg

        if (pkg == launcherPkg) { Session.unlocked = null; return }
        if (!Prefs.enabled(this)) return

        if (Session.unlocked == pkg) {
            if (now - Session.leftAt <= Prefs.graceMs(this)) return
            Session.unlocked = null
        }
        if (pkg in Prefs.locked(this)) {
            startActivity(
                Intent(this, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("pkg", pkg)
            )
        }
    }

    override fun onInterrupt() {}
}
