package com.example.applock

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32) }
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        root.addView(Switch(this).apply {
            text = "Tüm kilitler aktif"
            textSize = 18f
            setPadding(0, 0, 0, 32)
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                Prefs.setEnabled(this@MainActivity, on)
                if (!on) Session.unlocked = null
            }
        })
        btn("1) Erişilebilirlik iznini aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2) PIN belirle") { setPin() }
        btn("3) Desen belirle") { setPattern() }
        val delayBtn = Button(this)
        fun delayLabel() = "4) Tekrar kilit süresi: " + delayName(Prefs.graceMs(this))
        delayBtn.text = delayLabel()
        delayBtn.setOnClickListener { pickDelay { delayBtn.text = delayLabel() } }
        root.addView(delayBtn)
        btn("5) Kilit ekranı mesajı") { setMessage() }

        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val lv = ListView(this).apply { choiceMode = ListView.CHOICE_MODE_MULTIPLE }
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice,
            apps.map { it.loadLabel(pm).toString() })
        val locked = Prefs.locked(this)
        apps.forEachIndexed { i, a -> lv.setItemChecked(i, a.activityInfo.packageName in locked) }
        lv.setOnItemClickListener { _, _, _, _ ->
            val s = HashSet<String>()
            apps.forEachIndexed { i, a -> if (lv.isItemChecked(i)) s.add(a.activityInfo.packageName) }
            Prefs.setLocked(this, s)
        }
        root.addView(lv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val hasSecret = Prefs.has(this, "pin") || Prefs.has(this, "pattern")
        if (hasSecret && !Session.mainOk) {
            startActivity(Intent(this, LockActivity::class.java).putExtra("self", true))
            finish()
        }
    }

    private val delays = longArrayOf(0, 15_000, 30_000, 60_000, 300_000)
    private val delayNames = arrayOf("Hemen", "15 saniye", "30 saniye", "1 dakika", "5 dakika")

    private fun delayName(ms: Long) = delayNames[delays.indexOf(ms).coerceAtLeast(0)]

    private fun pickDelay(done: () -> Unit) {
        val cur = delays.indexOf(Prefs.graceMs(this)).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Uygulamadan çıkınca tekrar kilitle")
            .setSingleChoiceItems(delayNames, cur) { d, i ->
                Prefs.setGraceMs(this, delays[i]); done(); d.dismiss()
            }.show()
    }

    private fun setMessage() {
        val et = EditText(this).apply {
            hint = "Kilit ekranında görünecek mesaj"
            setText(Prefs.message(this@MainActivity))
            setSelection(text.length)
        }
        AlertDialog.Builder(this).setTitle("Kilit ekranı mesajı").setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                Prefs.setMessage(this, et.text.toString().trim()); toast("Kaydedildi")
            }.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun setPin() {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("Yeni PIN (en az 4 hane)").setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                if (et.text.length >= 4) { Prefs.set(this, "pin", et.text.toString()); Session.mainOk = true; toast("PIN kaydedildi") }
                else toast("En az 4 hane")
            }.show()
    }

    private fun setPattern() {
        var first: String? = null
        lateinit var dlg: AlertDialog
        val pv = PatternView(this) { s ->
            if (first == null) { first = s; toast("Onaylamak için tekrar çiz") }
            else if (first == s) { Prefs.set(this, "pattern", s); Session.mainOk = true; toast("Desen kaydedildi"); dlg.dismiss() }
            else { first = null; toast("Eşleşmedi, baştan çiz") }
        }
        dlg = AlertDialog.Builder(this).setTitle("Desen çiz").setView(pv).create()
        dlg.show()
    }
}
